import React, { useMemo, useState } from 'react';
import { STATUSES, URGENTE_COLOR, CARGA_COLOR } from '../../services/statusConfig';
import { CARGA_POR_DIA, CIDADE_SEMPRE } from '../../services/cargaConfig';

const SERVICE_FILTERS = [
  { key: 'dobra', label: 'Dobra' },
  { key: 'corte', label: 'Corte' },
  { key: 'calandra', label: 'Calandra' },
];

const ADVANCED_STATUSES = STATUSES.filter(s => s.value !== 'Ready');

export default function FilterBar({
  search,
  onSearch,
  filterStatus,
  onFilterStatus,
  advancedFilters,
  onAdvancedFilters,
  total,
}) {
  const [open, setOpen] = useState(false);
  const cities = useMemo(() => {
    const all = Object.values(CARGA_POR_DIA).flat();
    return [CIDADE_SEMPRE, ...Array.from(new Set(all)).sort((a, b) => a.localeCompare(b))];
  }, []);

  const serviceCount = Object.values(advancedFilters.services || {}).filter(Boolean).length;
  const advancedCount = [
    advancedFilters.status !== 'all',
    advancedFilters.city !== 'all',
    serviceCount > 0,
    advancedFilters.urgent,
    advancedFilters.withCarga,
  ].filter(Boolean).length;

  const updateAdvanced = patch => onAdvancedFilters({ ...advancedFilters, ...patch });
  const toggleService = key => onAdvancedFilters({
    ...advancedFilters,
    services: {
      ...advancedFilters.services,
      [key]: !advancedFilters.services?.[key],
    },
  });

  return (
    <div className="flex flex-col gap-3 px-6 py-4 border-b border-[#1c1c1c] flex-shrink-0">
      <div className="relative max-w-sm z-10">
        <svg className="absolute left-3 top-1/2 -translate-y-1/2 text-[#555]" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
        </svg>
        <input
          type="text"
          value={search}
          onChange={e => onSearch(e.target.value)}
          placeholder="Buscar cards..."
          className="w-full bg-[#1c1c1c] border border-[#2a2a2a] rounded-xl pl-9 pr-4 py-2 text-[#f0f0f0] text-sm placeholder-[#555] outline-none focus:border-[#2563eb] transition-all"
        />
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <button
          onClick={() => onFilterStatus('fila')}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${filterStatus === 'fila' ? 'bg-[#2a2a2a] text-[#f0f0f0]' : 'text-[#555] hover:text-[#8a8a8a] hover:bg-[#1c1c1c]'}`}
        >
          Fila <span className="ml-1 text-[#555]">{total}</span>
        </button>

        <button
          onClick={() => onFilterStatus('Ready')}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 ${filterStatus === 'Ready' ? 'bg-[#2a2a2a] text-[#f0f0f0]' : 'text-[#555] hover:text-[#8a8a8a] hover:bg-[#1c1c1c]'}`}
        >
          <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: '#16a34a' }} />
          Pronto
        </button>

        <button
          onClick={() => updateAdvanced({ urgent: !advancedFilters.urgent })}
          className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5"
          style={advancedFilters.urgent
            ? { background: `${URGENTE_COLOR}20`, color: URGENTE_COLOR, border: `1px solid ${URGENTE_COLOR}40` }
            : { color: '#555' }
          }
        >
          <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: URGENTE_COLOR }} />
          Urgente
        </button>

        <button
          onClick={() => updateAdvanced({ withCarga: !advancedFilters.withCarga })}
          className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5"
          style={advancedFilters.withCarga
            ? { background: `${CARGA_COLOR}20`, color: CARGA_COLOR, border: `1px solid ${CARGA_COLOR}40` }
            : { color: '#555' }
          }
        >
          <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: CARGA_COLOR }} />
          Carga
        </button>

        <div className="relative">
          <button
            onClick={() => setOpen(v => !v)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 ${open || advancedCount > 0 ? 'bg-[#2a2a2a] text-[#f0f0f0]' : 'text-[#555] hover:text-[#8a8a8a] hover:bg-[#1c1c1c]'}`}
          >
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M3 5h18M6 12h12M10 19h4" />
            </svg>
            Avancado
            {advancedCount > 0 && <span className="text-[#8a8a8a]">{advancedCount}</span>}
          </button>

          {open && (
            <div className="absolute left-0 top-full mt-2 z-40 w-[320px] rounded-xl border border-[#2a2a2a] bg-[#141414] shadow-modal p-4">
              <div className="grid gap-3">
                <label className="grid gap-1 text-xs text-[#8a8a8a]">
                  Status
                  <select
                    value={advancedFilters.status}
                    onChange={e => updateAdvanced({ status: e.target.value })}
                    className="bg-[#1c1c1c] border border-[#2a2a2a] rounded-lg px-3 py-2 text-[#f0f0f0] outline-none"
                  >
                    <option value="all">Todos da fila</option>
                    {ADVANCED_STATUSES.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
                  </select>
                </label>

                <label className="grid gap-1 text-xs text-[#8a8a8a]">
                  Cidade
                  <select
                    value={advancedFilters.city}
                    onChange={e => updateAdvanced({ city: e.target.value })}
                    className="bg-[#1c1c1c] border border-[#2a2a2a] rounded-lg px-3 py-2 text-[#f0f0f0] outline-none"
                  >
                    <option value="all">Todas</option>
                    {cities.map(city => <option key={city} value={city}>{city}</option>)}
                  </select>
                </label>

                <div>
                  <p className="text-xs text-[#8a8a8a] mb-2">Servicos</p>
                  <div className="flex flex-wrap gap-2">
                    {SERVICE_FILTERS.map(service => (
                      <button
                        key={service.key}
                        onClick={() => toggleService(service.key)}
                        className={`px-3 py-1.5 rounded-lg border text-xs transition-all ${advancedFilters.services?.[service.key] ? 'border-[#2563eb] bg-[#2563eb]/15 text-[#f0f0f0]' : 'border-[#2a2a2a] text-[#555] hover:text-[#8a8a8a]'}`}
                      >
                        {service.label}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => onAdvancedFilters({ status: 'all', city: 'all', services: {}, urgent: false, withCarga: false })}
                  className="mt-1 py-2 rounded-lg border border-[#2a2a2a] text-[#8a8a8a] text-xs hover:bg-[#1c1c1c]"
                >
                  Limpar filtros
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
