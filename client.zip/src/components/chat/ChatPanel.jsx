import React, { useEffect, useRef, useState } from 'react';
import api from '../../services/api';
import socket from '../../services/socket';
import { useAuth } from '../../contexts/AuthContext';

function formatTime(value) {
  if (!value) return '';
  return new Date(value).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}

function formatSize(bytes) {
  if (!bytes) return '';
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export default function ChatPanel({ onClose }) {
  const { user } = useAuth();
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [error, setError] = useState('');
  const [sendingFile, setSendingFile] = useState(false);
  const bottomRef = useRef(null);
  const fileRef = useRef(null);

  useEffect(() => {
    let mounted = true;

    api.get('/api/chat/history')
      .then(res => { if (mounted) setMessages(res.data); })
      .catch(() => { if (mounted) setError('Nao foi possivel carregar o chat.'); });

    const handleMessage = msg => setMessages(prev => [...prev, msg]);
    const handleDeleted = ({ id }) => setMessages(prev => prev.filter(msg => msg.id !== Number(id)));
    const handleCleared = () => setMessages([]);
    const handleError = payload => setError(payload?.message || 'Erro no chat.');

    socket.on('chat:message', handleMessage);
    socket.on('chat:deleted', handleDeleted);
    socket.on('chat:cleared', handleCleared);
    socket.on('chat:error', handleError);

    return () => {
      mounted = false;
      socket.off('chat:message', handleMessage);
      socket.off('chat:deleted', handleDeleted);
      socket.off('chat:cleared', handleCleared);
      socket.off('chat:error', handleError);
    };
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length]);

  const sendText = (event) => {
    event.preventDefault();
    const trimmed = text.trim();
    if (!trimmed) return;
    socket.emit('chat:send', { text: trimmed });
    setText('');
    setError('');
  };

  const sendFile = async (event) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;

    const allowed = ['png', 'jpg', 'jpeg', 'dxf', 'dwg', 'pdf'];
    const ext = file.name.toLowerCase().split('.').pop();
    if (!allowed.includes(ext)) {
      setError('Use PNG, JPG, DXF, DWG ou PDF.');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setError('Arquivo maximo: 5 MB.');
      return;
    }

    setSendingFile(true);
    setError('');

    const reader = new FileReader();
    reader.onload = () => {
      socket.emit('chat:file', { file_name: file.name, file_data: reader.result });
      setSendingFile(false);
    };
    reader.onerror = () => {
      setError('Nao foi possivel ler o arquivo.');
      setSendingFile(false);
    };
    reader.readAsDataURL(file);
  };

  const deleteMessage = async (id) => {
    try {
      await api.delete(`/api/chat/${id}`);
      socket.emit('chat:delete', { id });
    } catch {
      setError('Nao foi possivel excluir a mensagem.');
    }
  };

  return (
    <aside className="fixed right-0 top-0 z-50 h-screen w-[380px] max-w-[92vw] bg-[#0f0f0f] border-l border-[#1c1c1c] shadow-modal flex flex-col animate-fade-in">
      <div className="h-14 px-4 border-b border-[#1c1c1c] flex items-center justify-between">
        <div>
          <h2 className="text-[#f0f0f0] text-sm font-semibold">Chat</h2>
          <p className="text-[#555] text-[11px]">{messages.length} mensagens</p>
        </div>
        <button onClick={onClose} className="w-8 h-8 rounded-lg text-[#8a8a8a] hover:text-[#f0f0f0] hover:bg-[#1c1c1c] transition-colors" title="Fechar chat">
          <svg className="mx-auto" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <path d="M18 6 6 18M6 6l12 12" />
          </svg>
        </button>
      </div>

      {error && (
        <div className="mx-4 mt-3 px-3 py-2 rounded-lg bg-[#ef4444]/10 border border-[#ef4444]/25 text-[#ef4444] text-xs">
          {error}
        </div>
      )}

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
        {messages.length === 0 ? (
          <div className="h-full flex items-center justify-center text-[#555] text-sm">Nenhuma mensagem</div>
        ) : messages.map(msg => {
          const mine = msg.username === user?.username;
          const canDelete = mine || user?.role === 'creator';
          return (
            <div key={msg.id} className={`flex ${mine ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[82%] rounded-xl px-3 py-2 border ${mine ? 'bg-[#2563eb]/15 border-[#2563eb]/30' : 'bg-[#141414] border-[#242424]'}`}>
                <div className="flex items-center gap-2 mb-1">
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: msg.color || '#3b82f6' }} />
                  <span className="text-[#f0f0f0] text-xs font-medium">{msg.display_name || msg.username}</span>
                  <span className="text-[#555] text-[10px]">{formatTime(msg.created_at)}</span>
                  {canDelete && (
                    <button onClick={() => deleteMessage(msg.id)} className="ml-auto text-[#555] hover:text-[#ef4444]" title="Excluir mensagem">
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                        <path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14" />
                      </svg>
                    </button>
                  )}
                </div>

                {msg.text && <p className="text-[#d8d8d8] text-sm leading-relaxed whitespace-pre-wrap break-words">{msg.text}</p>}

                {msg.file_url && (
                  <a href={msg.file_url} target="_blank" rel="noreferrer" className="mt-2 flex items-center gap-2 rounded-lg border border-[#2a2a2a] bg-[#1c1c1c] px-3 py-2 text-xs text-[#f0f0f0] hover:border-[#3a3a3a]">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                      <path d="M14 2v6h6" />
                    </svg>
                    <span className="truncate">{msg.file_name || 'Arquivo'}</span>
                    <span className="text-[#555] flex-shrink-0">{formatSize(msg.file_size)}</span>
                  </a>
                )}
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      <form onSubmit={sendText} className="p-4 border-t border-[#1c1c1c] flex items-center gap-2">
        <input ref={fileRef} type="file" className="hidden" accept=".png,.jpg,.jpeg,.dxf,.dwg,.pdf" onChange={sendFile} />
        <button type="button" onClick={() => fileRef.current?.click()} disabled={sendingFile} className="w-10 h-10 rounded-xl border border-[#2a2a2a] text-[#8a8a8a] hover:text-[#f0f0f0] hover:bg-[#1c1c1c] disabled:opacity-50" title="Enviar arquivo">
          <svg className="mx-auto" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <path d="M21.44 11.05 12.25 20.24a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" />
          </svg>
        </button>
        <input
          value={text}
          onChange={e => setText(e.target.value)}
          maxLength={500}
          placeholder="Mensagem..."
          className="flex-1 h-10 bg-[#1c1c1c] border border-[#2a2a2a] rounded-xl px-3 text-[#f0f0f0] text-sm outline-none focus:border-[#2563eb]"
        />
        <button type="submit" className="w-10 h-10 rounded-xl bg-[#2563eb] text-white hover:bg-[#1d4ed8]" title="Enviar">
          <svg className="mx-auto" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="m22 2-7 20-4-9-9-4Z" />
            <path d="M22 2 11 13" />
          </svg>
        </button>
      </form>
    </aside>
  );
}
