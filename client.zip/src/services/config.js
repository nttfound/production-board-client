export const API_BASE_URL =
  process.env.REACT_APP_API_URL ||
  'https://production-board-server-production-ff04.up.railway.app';
